namespace ACE.Adapter.GDLE.Models
{
    public class QuestValue
    {
        public string fullname { get; set; }
        public int maxsolves { get; set; }
        public int mindelta { get; set; }
    }
}
