namespace ACE.Adapter.GDLE.Models
{
    public class Frame
    {
        public Origin origin { get; set; }
        public Angles angles { get; set; }
    }
}
