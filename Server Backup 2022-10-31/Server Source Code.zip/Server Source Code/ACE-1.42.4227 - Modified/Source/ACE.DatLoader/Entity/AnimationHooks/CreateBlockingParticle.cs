
namespace ACE.DatLoader.Entity.AnimationHooks
{
    public class CreateBlockingParticle : CreateParticleHook
    {
    }
}
