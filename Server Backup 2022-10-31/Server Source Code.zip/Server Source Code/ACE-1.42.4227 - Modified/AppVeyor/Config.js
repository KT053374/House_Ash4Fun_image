﻿{
  "Server": {
    "WorldName": "ACEmulator",
    "Welcome": "Welcome to this ACE server!\nFor more information visit https://emulator.ac",
    "Network": {
      "Host": "127.0.0.1",
      "Port": 9000
    },
    "Accounts": {
      "OverrideCharacterPermissions": true,
      "DefaultAccessLevel": 5
    },
    "DatFilesDirectory": "c:\\Turbine",
    "ShutdownInterval": "60"
  },
  "MySql": {
    "Authentication": {
      "Host": "127.0.0.1",
      "Port": 3306,
      "Database": "ace_auth",
      "Username": "root",
      "Password": "Password12!"
    },
    "Shard": {
      "Host": "127.0.0.1",
      "Port": 3306,
      "Database": "ace_shard",
      "Username": "root",
      "Password": "Password12!"
    },
    "World": {
      "Host": "127.0.0.1",
      "Port": 3306,
      "Database": "ace_world",
      "Username": "root",
      "Password": "Password12!"
    }
  }
}
