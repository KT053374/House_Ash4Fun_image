USE `ace_shard`;

DELETE FROM biota_properties_bool
WHERE id > 0 AND `type` = 106;
