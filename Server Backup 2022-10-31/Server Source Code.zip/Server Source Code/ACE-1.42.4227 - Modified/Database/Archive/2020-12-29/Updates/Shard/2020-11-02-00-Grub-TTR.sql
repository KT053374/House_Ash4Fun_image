/* Small Olthoi Grub */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=24269 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Gold Remoran */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=32216 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Tipped Pack Cow */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=33965 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Scold */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=34406 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Abominable Pack Snowman */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=34407 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Mr. P. Holiday Pack Doll */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=34405 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Wedding Cake */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=14910 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Plush Tusker */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=9169 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Velveteen Olthoi */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=9170 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Mosswart */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=9171 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Drudge */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=9172 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Ursuin */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=9173 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Lugian */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=9174 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Cow */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=9175 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Grievver */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=9176 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Scarecrow */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=9177 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Virindi */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=9178 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Golem */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=9179 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Idol */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=9180 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Carved Tusker Statue */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=22620 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Tremendous Monouga Pack Doll */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=25534 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Asheron */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=29916 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Bael'Zharon */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=29917 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Gaerlan */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=29918 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Burun Kukuur */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=29919 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Levistras */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=29920 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Martine */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=29921 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;

/* Pack Ancient Olthoi Queen */
DELETE biota_properties_float FROM biota_properties_float
INNER JOIN biota ON biota.id=biota_properties_float.object_Id
WHERE biota.weenie_Class_Id=29922 AND biota_properties_float.`type`=44 /* TimeToRot */ AND biota_properties_float.value=-1;
