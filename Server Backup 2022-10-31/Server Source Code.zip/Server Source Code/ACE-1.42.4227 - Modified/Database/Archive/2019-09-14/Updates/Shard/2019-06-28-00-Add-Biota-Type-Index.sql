CREATE INDEX biota_type_idx ON biota(weenie_Type);
