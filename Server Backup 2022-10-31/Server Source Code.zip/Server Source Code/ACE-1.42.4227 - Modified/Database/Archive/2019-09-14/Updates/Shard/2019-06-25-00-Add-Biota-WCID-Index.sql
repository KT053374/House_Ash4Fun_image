CREATE INDEX biota_wcid_idx ON biota(weenie_Class_Id);
