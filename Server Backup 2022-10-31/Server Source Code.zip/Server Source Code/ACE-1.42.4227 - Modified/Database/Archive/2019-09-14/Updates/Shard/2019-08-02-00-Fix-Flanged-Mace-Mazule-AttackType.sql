update ace_shard.biota_properties_int set value=4 where `type`=47 and value=1028;

