UPDATE biota SET weenie_Type=3 /* MissileLauncher */ WHERE weenie_Class_Id=51988 /* Rynthid Tentacle Bow */;
