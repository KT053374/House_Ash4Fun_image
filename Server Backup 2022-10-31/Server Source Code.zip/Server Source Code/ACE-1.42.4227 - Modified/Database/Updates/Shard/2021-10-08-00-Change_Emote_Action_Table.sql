ALTER TABLE `biota_properties_emote_action`
CHANGE COLUMN `motion` `motion` INT UNSIGNED NULL DEFAULT NULL ;
