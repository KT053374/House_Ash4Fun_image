/*
-- Query: SELECT * FROM ace_auth.accesslevel
-- Date: 2018-02-14 13:19
*/
INSERT INTO `accesslevel` (`level`,`name`,`prefix`) VALUES (0,'Player','');
INSERT INTO `accesslevel` (`level`,`name`,`prefix`) VALUES (1,'Advocate','');
INSERT INTO `accesslevel` (`level`,`name`,`prefix`) VALUES (2,'Sentinel','Sentinel');
INSERT INTO `accesslevel` (`level`,`name`,`prefix`) VALUES (3,'Envoy','Envoy');
INSERT INTO `accesslevel` (`level`,`name`,`prefix`) VALUES (4,'Developer','');
INSERT INTO `accesslevel` (`level`,`name`,`prefix`) VALUES (5,'Admin','Admin');
