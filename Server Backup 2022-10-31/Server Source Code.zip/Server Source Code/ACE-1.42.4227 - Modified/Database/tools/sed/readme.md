This folder contains files sourced from the following location:

sed for Windows

http://gnuwin32.sourceforge.net/packages/sed.htm

http://sourceforge.net/projects/gnuwin32/files//sed/4.2.1/sed-4.2.1-bin.zip/download

http://sourceforge.net/projects/gnuwin32/files//sed/4.2.1/sed-4.2.1-dep.zip/download
