DELETE FROM `quest` WHERE `name` = 'NewIsparRomoranTailsStart';

INSERT INTO `quest` (`name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`)
VALUES ('NewIsparRomoranTailsStart', 0, 1, 'Romoran Tail', '2019-02-04 06:51:50');

DELETE FROM `quest` WHERE `name` = 'NewIsparRomoranTailsWait';

INSERT INTO `quest` (`name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`)
VALUES ('NewIsparRomoranTailsWait', 244800, -1, 'Romoran Tail', '2019-02-04 06:51:50');