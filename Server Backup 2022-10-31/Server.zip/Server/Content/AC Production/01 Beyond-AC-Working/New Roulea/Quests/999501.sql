DELETE FROM `quest` WHERE `name` = 'ArmyKnife';
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`) VALUES ('999501', 'ArmyKnife', '0', '10', 'Roulean Army Knife');