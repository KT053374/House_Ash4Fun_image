
DELETE FROM `quest` WHERE (`id` = '500005');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('500005', 'YV', '0', '1', 'Yanshi Virindi', '2019-09-05 19:03:38');