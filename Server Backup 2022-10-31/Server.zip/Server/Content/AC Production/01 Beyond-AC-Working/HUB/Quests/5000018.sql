
DELETE FROM `quest` WHERE (`id` = '5000018');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000018', 'WardenFenm', '0', '1', 'Warden for Fenm', '2019-09-05 11:37:00');
