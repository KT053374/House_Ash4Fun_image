DELETE FROM `landblock_instance` WHERE `landblock` = 0x016C;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7016C000, 2000500, 0x016C01BC, 54.6035, -33.6872, 0.00999999, -0.754562, 0, 0, -0.656229, False, '2020-05-07 14:27:29');
/* @teleloc 0x016C01BC [54.603500 -33.687199 0.010000] -0.754562 0.000000 0.000000 -0.656229 */
