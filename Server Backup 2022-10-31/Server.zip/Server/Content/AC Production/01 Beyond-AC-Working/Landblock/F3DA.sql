DELETE FROM `landblock_instance` WHERE `landblock` =62426;


INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA000,5000267, 0xF3DA0039, 172.4973, 2.296548, 0, 0.4966032, 0, 0, -0.8679777, False, '2020-01-12 00:02:06'); /* Old Gravestone */
/* @teleloc 0xF3DA0039 [172.4973 2.296548 0] 0.4966032 0 0 -0.8679777 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA001,5000267, 0xF3DA0039, 173.5543, 7.644789, 0, 0.6434557, 0, 0, -0.7654833, False, '2020-01-12 00:02:34'); /* Old Gravestone */
/* @teleloc 0xF3DA0039 [173.5543 7.644789 0] 0.6434557 0 0 -0.7654833 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA002,5000232, 0xF3DA0039, 173.2445, 13.49088, 0, 0.6990043, 0, 0, -0.7151175, False, '2020-01-12 00:03:06'); /* Old Gravestone */
/* @teleloc 0xF3DA0039 [173.2445 13.49088 0] 0.6990043 0 0 -0.7151175 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA003,5000267, 0xF3DA0039, 173.1944, 17.36964, 0, 0.7338718, 0, 0, -0.679288, False, '2020-01-12 00:03:21'); /* Old Gravestone */
/* @teleloc 0xF3DA0039 [173.1944 17.36964 0] 0.7338718 0 0 -0.679288 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA004,5000267, 0xF3DA0039, 172.8634, 21.61763, 0, 0.7253236, 0, 0, -0.6884081, False, '2020-01-12 00:03:27'); /* Old Gravestone */
/* @teleloc 0xF3DA0039 [172.8634 21.61763 0] 0.7253236 0 0 -0.6884081 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA005,5000233, 0xF3DA003A, 172.6692, 26.24146, 0, 0.7078884, 0, 0, -0.7063242, False, '2020-01-12 00:03:36'); /* Old Gravestone */
/* @teleloc 0xF3DA003A [172.6692 26.24146 0] 0.7078884 0 0 -0.7063242 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA006,5000267, 0xF3DA003A, 172.7053, 30.08852, 0, 0.7166619, 0, 0, -0.6974207, False, '2020-01-12 00:04:06'); /* Old Gravestone */
/* @teleloc 0xF3DA003A [172.7053 30.08852 0] 0.7166619 0 0 -0.6974207 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA007,5000234, 0xF3DA003A, 172.4537, 33.83033, 0, 0.7338718, 0, 0, -0.679288, False, '2020-01-12 00:04:20'); /* Old Gravestone */
/* @teleloc 0xF3DA003A [172.4537 33.83033 0] 0.7338718 0 0 -0.679288 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA008,5000267, 0xF3DA003A, 172.2145, 37.58413, 0, 0.7078885, 0, 0, -0.7063242, False, '2020-01-12 00:04:28'); /* Old Gravestone */
/* @teleloc 0xF3DA003A [172.2145 37.58413 0] 0.7078885 0 0 -0.7063242 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA009,5000235, 0xF3DA003A, 171.9198, 41.66418, 0, 0.7338718, 0, 0, -0.679288, False, '2020-01-12 00:04:37'); /* Old Gravestone */
/* @teleloc 0xF3DA003A [171.9198 41.66418 0] 0.7338718 0 0 -0.679288 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA00A,5000267, 0xF3DA0032, 166.9099, 41.2766, 0, 0.7338718, 0, 0, -0.679288, False, '2020-01-12 00:04:45'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [166.9099 41.2766 0] 0.7338718 0 0 -0.679288 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA00B,5000235, 0xF3DA0032, 167.246, 37.18987, 0, 0.6717023, 0, 0, -0.7408212, False, '2020-01-12 00:04:59'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [167.246 37.18987 0] 0.6717023 0 0 -0.7408212 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA00C,5000267, 0xF3DA0032, 167.615, 33.52103, 0, 0.690011, 0, 0, -0.7237989, False, '2020-01-12 00:05:03'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [167.615 33.52103 0] 0.690011 0 0 -0.7237989 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA00D,5000267, 0xF3DA003A, 168.1078, 30.07606, 0, 0.6043934, 0, 0, -0.7966861, False, '2020-01-12 00:05:06'); /* Old Gravestone */
/* @teleloc 0xF3DA003A [168.1078 30.07606 0] 0.6043934 0 0 -0.7966861 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA00E,5000236, 0xF3DA003A, 168.0675, 26.3931, 0, 0.7423052, 0, 0, -0.6700619, False, '2020-01-12 00:05:20'); /* Old Gravestone */
/* @teleloc 0xF3DA003A [168.0675 26.3931 0] 0.7423052 0 0 -0.6700619 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA00F,5000237, 0xF3DA0039, 168.1871, 22.10127, 0, 0.7338718, 0, 0, -0.679288, False, '2020-01-12 00:05:36'); /* Old Gravestone */
/* @teleloc 0xF3DA0039 [168.1871 22.10127 0] 0.7338718 0 0 -0.679288 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA010,5000267, 0xF3DA0039, 168.5149, 17.62932, 0, 0.6900108, 0, 0, -0.723799, False, '2020-01-12 00:05:44'); /* Old Gravestone */
/* @teleloc 0xF3DA0039 [168.5149 17.62932 0] 0.6900108 0 0 -0.723799 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA011,5000238, 0xF3DA0039, 168.7429, 14.06618, 0, 0.7253234, 0, 0, -0.6884083, False, '2020-01-12 00:06:00'); /* Old Gravestone */
/* @teleloc 0xF3DA0039 [168.7429 14.06618 0] 0.7253234 0 0 -0.6884083 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA012,5000267, 0xF3DA0039, 168.4882, 9.14177, 0, 0.5740995, 0, 0, -0.8187855, False, '2020-01-12 00:06:07'); /* Old Gravestone */
/* @teleloc 0xF3DA0039 [168.4882 9.14177 0] 0.5740995 0 0 -0.8187855 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA013,5000239, 0xF3DA0031, 167.9947, 5.639786, 0, 0.5218378, 0, 0, -0.8530447, False, '2020-01-12 00:06:20'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [167.9947 5.639786 0] 0.5218378 0 0 -0.8530447 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA014,5000267, 0xF3DA0031, 166.2696, 1.961891, 0, 0.4785512, 0, 0, -0.8780596, False, '2020-01-12 00:06:26'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [166.2696 1.961891 0] 0.4785512 0 0 -0.8780596 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA015,5000267, 0xF3DA0031, 163.3169, 11.91552, 0, 0.684773, 0, 0, -0.7287565, False, '2020-01-12 00:06:56'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [163.3169 11.91552 0] 0.684773 0 0 -0.7287565 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA016,5000241, 0xF3DA0031, 163.2037, 16.35862, 0, 0.6379184, 0, 0, -0.770104, False, '2020-01-12 00:07:07'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [163.2037 16.35862 0] 0.6379184 0 0 -0.770104 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA017,5000267, 0xF3DA0031, 163.151, 20.48526, 0, 0.7116135, 0, 0, -0.7025712, False, '2020-01-12 00:07:11'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [163.151 20.48526 0] 0.7116135 0 0 -0.7025712 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA018,5000267, 0xF3DA0032, 163.2532, 24.40269, 0, 0.7289537, 0, 0, -0.6845631, False, '2020-01-12 00:07:17'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [163.2532 24.40269 0] 0.7289537 0 0 -0.6845631 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA019,5000267, 0xF3DA0032, 163.3629, 28.31334, 0, 0.6663418, 0, 0, -0.7456464, False, '2020-01-12 00:07:30'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [163.3629 28.31334 0] 0.6663418 0 0 -0.7456464 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA01A,5000242, 0xF3DA0032, 163.6658, 32.86006, 0, 0.7116134, 0, 0, -0.7025713, False, '2020-01-12 00:07:44'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [163.6658 32.86006 0] 0.7116134 0 0 -0.7025713 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA01B,5000267, 0xF3DA0032, 163.6344, 37.07372, 0, 0.7374534, 0, 0, -0.6753981, False, '2020-01-12 00:07:49'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [163.6344 37.07372 0] 0.7374534 0 0 -0.6753981 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA01C,5000243, 0xF3DA0032, 158.4702, 38.57238, 0, 0.6663419, 0, 0, -0.7456463, False, '2020-01-12 00:08:11'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [158.4702 38.57238 0] 0.6663419 0 0 -0.7456463 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA01D,5000267, 0xF3DA0032, 158.7457, 33.9789, 0, 0.702776, 0, 0, -0.7114112, False, '2020-01-12 00:08:15'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [158.7457 33.9789 0] 0.702776 0 0 -0.7114112 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA01E,5000267, 0xF3DA0032, 158.6684, 29.93909, 0, 0.7203399, 0, 0, -0.6936213, False, '2020-01-12 00:08:26'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [158.6684 29.93909 0] 0.7203399 0 0 -0.6936213 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA01F,5000244, 0xF3DA0032, 158.3493, 25.38643, 0, 0.6938287, 0, 0, -0.7201401, False, '2020-01-12 00:08:35'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [158.3493 25.38643 0] 0.6938287 0 0 -0.7201401 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA020,5000245, 0xF3DA0031, 158.4728, 20.9068, 0, 0.7116135, 0, 0, -0.7025712, False, '2020-01-12 00:08:40'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [158.4728 20.9068 0] 0.7116135 0 0 -0.7025712 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA021,5000267, 0xF3DA0031, 158.667, 16.93347, 0, 0.7116135, 0, 0, -0.7025712, False, '2020-01-12 00:08:51'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [158.667 16.93347 0] 0.7116135 0 0 -0.7025712 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA022,5000267, 0xF3DA0031, 158.642, 12.9175, 0, 0.6847729, 0, 0, -0.7287565, False, '2020-01-12 00:08:53'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [158.642 12.9175 0] 0.6847729 0 0 -0.7287565 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA023,5000246, 0xF3DA0031, 158.2158, 7.394169, 0, 0.6663421, 0, 0, -0.7456461, False, '2020-01-12 00:09:06'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [158.2158 7.394169 0] 0.6663421 0 0 -0.7456461 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA024,5000267, 0xF3DA0031, 158.1236, 2.313027, 0, 0.6847731, 0, 0, -0.7287563, False, '2020-01-12 00:09:12'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [158.1236 2.313027 0] 0.6847731 0 0 -0.7287563 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA025,5000248, 0xF3DA0031, 153.2594, 0.6565729, 0, 0.684503, 0, 0, -0.72901, False, '2020-01-12 00:09:44'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [153.2594 0.6565729 0] 0.684503 0 0 -0.72901 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA026,5000249, 0xF3DA0031, 153.551, 5.721419, 0, 0.7113532, 0, 0, -0.7028347, False, '2020-01-12 00:09:51'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [153.551 5.721419 0] 0.7113532 0 0 -0.7028347 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA027,5000267, 0xF3DA0031, 153.5102, 9.849973, 0, 0.6083038, 0, 0, -0.7937043, False, '2020-01-12 00:09:57'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [153.5102 9.849973 0] 0.6083038 0 0 -0.7937043 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA028,5000267, 0xF3DA0031, 153.5298, 13.78744, 0, 0.7455912, 0, 0, -0.6664035, False, '2020-01-12 00:10:02'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [153.5298 13.78744 0] 0.7455912 0 0 -0.6664035 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA029,5000250, 0xF3DA0031, 153.9892, 17.73612, 0, 0.675337, 0, 0, -0.7375093, False, '2020-01-12 00:10:11'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [153.9892 17.73612 0] 0.675337 0 0 -0.7375093 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA02A,5000267, 0xF3DA0031, 153.7941, 22.05256, 0, 0.7025123, 0, 0, -0.7116715, False, '2020-01-12 00:10:15'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [153.7941 22.05256 0] 0.7025123 0 0 -0.7116715 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA02B,5000251, 0xF3DA0032, 153.8415, 25.71357, 0, 0.7025123, 0, 0, -0.7116715, False, '2020-01-12 00:10:20'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [153.8415 25.71357 0] 0.7025123 0 0 -0.7116715 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA02C,5000267, 0xF3DA0032, 154.1764, 29.54195, 0, 0.7286999, 0, 0, -0.6848332, False, '2020-01-12 00:10:24'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [154.1764 29.54195 0] 0.7286999 0 0 -0.6848332 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA02D,5000267, 0xF3DA0032, 154.3571, 33.53778, 0, 0.627954, 0, 0, -0.7782505, False, '2020-01-12 00:10:27'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [154.3571 33.53778 0] 0.627954 0 0 -0.7782505 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA02E,5000252, 0xF3DA0032, 154.121, 37.37766, 0, 0.7113531, 0, 0, -0.7028348, False, '2020-01-12 00:10:32'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [154.121 37.37766 0] 0.7113531 0 0 -0.7028348 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA02F,5000253, 0xF3DA0032, 149.3775, 38.43813, 0, 0.7113531, 0, 0, -0.7028348, False, '2020-01-12 00:10:43'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [149.3775 38.43813 0] 0.7113531 0 0 -0.7028348 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA030,5000267, 0xF3DA0032, 149.1196, 34.35977, 0, 0.7286999, 0, 0, -0.6848332, False, '2020-01-12 00:10:48'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [149.1196 34.35977 0] 0.7286999 0 0 -0.6848332 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA031,5000267, 0xF3DA0032, 149.0318, 30.6471, 0, 0.675337, 0, 0, -0.7375093, False, '2020-01-12 00:10:56'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [149.0318 30.6471 0] 0.675337 0 0 -0.7375093 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA032,5000254, 0xF3DA0032, 149.0549, 26.53556, 0, 0.6935618, 0, 0, -0.7203972, False, '2020-01-12 00:11:12'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [149.0549 26.53556 0] 0.6935618 0 0 -0.7203972 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA033,5000267, 0xF3DA0031, 148.8662, 21.93174, 0, 0.675337, 0, 0, -0.7375093, False, '2020-01-12 00:11:19'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [148.8662 21.93174 0] 0.675337 0 0 -0.7375093 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA034,5000255, 0xF3DA0031, 149.1531, 17.66669, 0, 0.6566903, 0, 0, -0.7541604, False, '2020-01-12 00:11:29'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [149.1531 17.66669 0] 0.6566903 0 0 -0.7541604 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA035,5000267, 0xF3DA0031, 149.1465, 14.35509, 0, 0.6472123, 0, 0, -0.7623098, False, '2020-01-12 00:11:33'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [149.1465 14.35509 0] 0.6472123 0 0 -0.7623098 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA036,5000267, 0xF3DA0031, 148.8902, 10.27236, 0, 0.684503, 0, 0, -0.72901, False, '2020-01-12 00:11:37'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [148.8902 10.27236 0] 0.684503 0 0 -0.72901 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA037,5000267, 0xF3DA0031, 148.8121, 6.235914, 0, 0.7372032, 0, 0, -0.675671, False, '2020-01-12 00:11:42'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [148.8121 6.235914 0] 0.7372032 0 0 -0.675671 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA038,5000267, 0xF3DA0031, 148.8072, 1.999796, 0, 0.7113532, 0, 0, -0.7028347, False, '2020-01-12 00:11:47'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [148.8072 1.999796 0] 0.7113532 0 0 -0.7028347 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA039,5000257, 0xF3DA0029, 143.1908, 0.726917, 0, -0.6640846, 0, 0, 0.7476574, False, '2020-01-12 00:12:19'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [143.1908 0.726917 0] -0.6640846 0 0 0.7476574 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA03A,5000267, 0xF3DA0029, 143.5737, 5.715271, 0, -0.6546873, 0, 0, 0.7558998, False, '2020-01-12 00:12:25'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [143.5737 5.715271 0] -0.6546873 0 0 0.7558998 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA03B,5000267, 0xF3DA0029, 143.9037, 10.06533, 0, -0.700622, 0, 0, 0.7135326, False, '2020-01-12 00:12:28'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [143.9037 10.06533 0] -0.700622 0 0 0.7135326 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA03C,5000267, 0xF3DA0031, 144.1925, 13.90567, 0, -0.6733784, 0, 0, 0.739298, False, '2020-01-12 00:12:45'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [144.1925 13.90567 0] -0.6733784 0 0 0.739298 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA03D,5000258, 0xF3DA0031, 144.6303, 17.87785, 0, -0.6916485, 0, 0, 0.7222343, False, '2020-01-12 00:12:53'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [144.6303 17.87785 0] -0.6916485 0 0 0.7222343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA03E,5000267, 0xF3DA0031, 144.7175, 22.05981, 0, -0.7094864, 0, 0, 0.7047192, False, '2020-01-12 00:12:58'); /* Old Gravestone */
/* @teleloc 0xF3DA0031 [144.7175 22.05981 0] -0.7094864 0 0 0.7047192 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA03F,5000259, 0xF3DA0032, 145.1009, 26.42441, 0, -0.5448993, 0, 0, 0.8385015, False, '2020-01-12 00:13:14'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [145.1009 26.42441 0] -0.5448993 0 0 0.8385015 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA040,5000260, 0xF3DA0032, 145.0868, 30.33702, 0, -0.7094862, 0, 0, 0.7047193, False, '2020-01-12 00:13:21'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [145.0868 30.33702 0] -0.7094862 0 0 0.7047193 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA041,5000267, 0xF3DA0032, 144.4423, 34.48767, 0, -0.7268807, 0, 0, 0.6867637, False, '2020-01-12 00:13:33'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [144.4423 34.48767 0] -0.7268807 0 0 0.6867637 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA042,5000261, 0xF3DA0032, 144.9089, 38.38897, 0, -0.6916484, 0, 0, 0.7222343, False, '2020-01-12 00:13:47'); /* Old Gravestone */
/* @teleloc 0xF3DA0032 [144.9089 38.38897 0] -0.6916484 0 0 0.7222343 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA043,5000267, 0xF3DA002A, 140.4036, 30.44878, 0, -0.5861262, 0, 0, 0.8102198, False, '2020-01-12 00:14:05'); /* Old Gravestone */
/* @teleloc 0xF3DA002A [140.4036 30.44878 0] -0.5861262 0 0 0.8102198 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA044,5000267, 0xF3DA0029, 139.2984, 18.17326, 0, -0.6916487, 0, 0, 0.7222341, False, '2020-01-12 00:14:11'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [139.2984 18.17326 0] -0.6916487 0 0 0.7222341 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA045,5000267, 0xF3DA0029, 139.7535, 14.13237, 0, -0.645188, 0, 0, 0.7640238, False, '2020-01-12 00:14:23'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [139.7535 14.13237 0] -0.645188 0 0 0.7640238 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA046,5000267, 0xF3DA0029, 139.5278, 5.999223, 0, -0.6640851, 0, 0, 0.747657, False, '2020-01-12 00:14:33'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [139.5278 5.999223 0] -0.6640851 0 0 0.747657 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA047,5000267, 0xF3DA0029, 133.804, 1.962048, 0, -0.7354086, 0, 0, 0.6776239, False, '2020-01-12 00:14:49'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [133.804 1.962048 0] -0.7354086 0 0 0.6776239 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA048,5000267, 0xF3DA0029, 134.8493, 10.50179, 0, -0.6640851, 0, 0, 0.7476569, False, '2020-01-12 00:14:57'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [134.8493 10.50179 0] -0.6640851 0 0 0.7476569 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA049,5000267, 0xF3DA0029, 134.9045, 14.91679, 0, -0.6733785, 0, 0, 0.7392979, False, '2020-01-12 00:15:04'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [134.9045 14.91679 0] -0.6733785 0 0 0.7392979 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA04A,5000267, 0xF3DA0029, 134.9198, 22.27804, 0, -0.6916485, 0, 0, 0.7222342, False, '2020-01-12 00:15:08'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [134.9198 22.27804 0] -0.6916485 0 0 0.7222342 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA04B,5000267, 0xF3DA002A, 134.7508, 34.52799, 0, -0.6825666, 0, 0, 0.7308234, False, '2020-01-12 00:15:14'); /* Old Gravestone */
/* @teleloc 0xF3DA002A [134.7508 34.52799 0] -0.6825666 0 0 0.7308234 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA04C,5000267, 0xF3DA002A, 128.6473, 30.1755, 0, -0.7182396, 0, 0, 0.6957958, False, '2020-01-12 00:15:19'); /* Old Gravestone */
/* @teleloc 0xF3DA002A [128.6473 30.1755 0] -0.7182396 0 0 0.6957958 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA04D,5000267, 0xF3DA002A, 128.4267, 25.24524, 0, -0.6825668, 0, 0, 0.7308233, False, '2020-01-12 00:15:22'); /* Old Gravestone */
/* @teleloc 0xF3DA002A [128.4267 25.24524 0] -0.6825668 0 0 0.7308233 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA04E,5000267, 0xF3DA0029, 128.8201, 15.06578, 0, -0.6733784, 0, 0, 0.739298, False, '2020-01-12 00:15:26'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [128.8201 15.06578 0] -0.6733784 0 0 0.739298 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA04F,5000263, 0xF3DA0029, 128.4731, 7.369929, 0, -0.6825668, 0, 0, 0.7308232, False, '2020-01-12 00:16:09'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [128.4731 7.369929 0] -0.6825668 0 0 0.7308232 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA050,5000264, 0xF3DA0029, 138.9707, 22.02067, 0, -0.6733783, 0, 0, 0.739298, False, '2020-01-12 00:16:22'); /* Old Gravestone */
/* @teleloc 0xF3DA0029 [138.9707 22.02067 0] -0.6733783 0 0 0.739298 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA051,5000265, 0xF3DA002A, 134.67, 29.93968, 0, -0.7006221, 0, 0, 0.7135325, False, '2020-01-12 00:16:31'); /* Old Gravestone */
/* @teleloc 0xF3DA002A [134.67 29.93968 0] -0.7006221 0 0 0.7135325 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA052,5000266, 0xF3DA002A, 139.3037, 37.69995, 0, -0.7521175, 0, 0, 0.6590291, False, '2020-01-12 00:16:43'); /* Old Gravestone */
/* @teleloc 0xF3DA002A [139.3037 37.69995 0] -0.7521175 0 0 0.6590291 */


INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA053,5000314, 0xF3DA0002, 20.34401, 34.04981, 0.055, 0.003539308, 0, 0, -0.9999937, False, '2020-01-12 01:01:39'); /* Memorial */
/* @teleloc 0xF3DA0002 [20.34401 34.04981 0.055] 0.003539308 0 0 -0.9999937 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA054,5000396, 0xF3DA0002, 19.8738, 37.00118, -0.002499994, -0.9995751, 0, 0, -0.02914936, False, '2020-01-12 01:03:17'); /* Helmet */
/* @teleloc 0xF3DA0002 [19.8738 37.00118 -0.002499994] -0.9995751 0 0 -0.02914936 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA055,5000397, 0xF3DA0002, 22.99634, 34.98206, -0.002499994, -0.7985907, 0, 0, 0.6018745, False, '2020-01-12 01:03:34'); /* Helmet */
/* @teleloc 0xF3DA0002 [22.99634 34.98206 -0.002499994] -0.7985907 0 0 0.6018745 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA056,5000398, 0xF3DA0002, 21.29921, 31.29533, -0.002499994, -0.1740588, 0, 0, 0.9847353, False, '2020-01-12 01:03:49'); /* Helmet */
/* @teleloc 0xF3DA0002 [21.29921 31.29533 -0.002499994] -0.1740588 0 0 0.9847353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA057,5000399, 0xF3DA0002, 17.87488, 33.33505, -0.002499994, 0.6151295, 0, 0, 0.7884261, False, '2020-01-12 01:04:14'); /* Helmet */
/* @teleloc 0xF3DA0002 [17.87488 33.33505 -0.002499994] 0.6151295 0 0 0.7884261 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA058,5000409, 0xF3DA0002, 18.17527, 35.33884, -0.015, 0.8277301, 0, 0, 0.5611264, False, '2020-01-12 01:04:59'); /* Horned Helm */
/* @teleloc 0xF3DA0002 [18.17527 35.33884 -0.015] 0.8277301 0 0 0.5611264 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA059,5000416, 0xF3DA0002, 21.68915, 36.50729, -0.002499994, 0.9540707, 0, 0, -0.2995816, False, '2020-01-12 01:05:17'); /* Chiran Helm */
/* @teleloc 0xF3DA0002 [21.68915 36.50729 -0.002499994] 0.9540707 0 0 -0.2995816 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA05A,5000427, 0xF3DA0002, 22.89926, 32.93121, -0.002500009, 0.4829687, 0, 0, -0.8756377, False, '2020-01-12 01:05:48'); /* Kabuton */
/* @teleloc 0xF3DA0002 [22.89926 32.93121 -0.002500009] 0.4829687 0 0 -0.8756377 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA05B,5000400, 0xF3DA0002, 19.50758, 31.79866, -0.002499994, -0.2555904, 0, 0, -0.9667851, False, '2020-01-12 01:05:57'); /* Helmet */
/* @teleloc 0xF3DA0002 [19.50758 31.79866 -0.002499994] -0.2555904 0 0 -0.9667851 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA05C,5000410, 0xF3DA0002, 17.88431, 31.84683, -0.015, -0.3741299, 0, 0, -0.9273763, False, '2020-01-12 01:06:10'); /* Horned Helm */
/* @teleloc 0xF3DA0002 [17.88431 31.84683 -0.015] -0.3741299 0 0 -0.9273763 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA05D,5000426, 0xF3DA0002, 20.17119, 30.52368, -0.002500009, -0.1082459, 0, 0, -0.9941242, False, '2020-01-12 01:06:25'); /* Kabuton */
/* @teleloc 0xF3DA0002 [20.17119 30.52368 -0.002500009] -0.1082459 0 0 -0.9941242 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA05E,5000420, 0xF3DA0002, 22.83786, 31.45253, -0.002499994, 0.2874291, 0, 0, -0.9578019, False, '2020-01-12 01:06:41'); /* Chiran Helm */
/* @teleloc 0xF3DA0002 [22.83786 31.45253 -0.002499994] 0.2874291 0 0 -0.9578019 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA05F,5000401, 0xF3DA0002, 23.99801, 33.89944, -0.002499994, 0.7287821, 0, 0, -0.6847457, False, '2020-01-12 01:06:59'); /* Helmet */
/* @teleloc 0xF3DA0002 [23.99801 33.89944 -0.002499994] 0.7287821 0 0 -0.6847457 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA060,5000402, 0xF3DA0002, 22.99554, 36.4387, -0.002499994, 0.8985884, 0, 0, -0.4387927, False, '2020-01-12 01:07:08'); /* Helmet */
/* @teleloc 0xF3DA0002 [22.99554 36.4387 -0.002499994] 0.8985884 0 0 -0.4387927 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA061,5000417, 0xF3DA0002, 20.95167, 37.78643, -0.002499994, 0.9861286, 0, 0, -0.1659829, False, '2020-01-12 01:07:25'); /* Chiran Helm */
/* @teleloc 0xF3DA0002 [20.95167 37.78643 -0.002499994] 0.9861286 0 0 -0.1659829 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA062,5000412, 0xF3DA0002, 18.33485, 36.84532, -0.015, 0.9408231, 0, 0, 0.3388981, False, '2020-01-12 01:07:35'); /* Horned Helm */
/* @teleloc 0xF3DA0002 [18.33485 36.84532 -0.015] 0.9408231 0 0 0.3388981 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA063,5000416, 0xF3DA0002, 17.05568, 34.37418, -0.002499994, 0.8134451, 0, 0, 0.5816417, False, '2020-01-12 01:07:46'); /* Chiran Helm */
/* @teleloc 0xF3DA0002 [17.05568 34.37418 -0.002499994] 0.8134451 0 0 0.5816417 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA064,5000412, 0xF3DA0002, 16.21456, 32.73075, -0.015, 0.6816759, 0, 0, 0.7316543, False, '2020-01-12 01:07:54'); /* Horned Helm */
/* @teleloc 0xF3DA0002 [16.21456 32.73075 -0.015] 0.6816759 0 0 0.7316543 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA065,5000424, 0xF3DA0002, 16.59861, 36.36904, -0.002500016, 0.8674484, 0, 0, 0.4975271, False, '2020-01-12 01:08:11'); /* Kabuton */
/* @teleloc 0xF3DA0002 [16.59861 36.36904 -0.002500016] 0.8674484 0 0 0.4975271 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA066,5000407, 0xF3DA0002, 19.33096, 38.33082, -0.002500001, 0.9954199, 0, 0, 0.0955994, False, '2020-01-12 01:08:23'); /* Helmet */
/* @teleloc 0xF3DA0002 [19.33096 38.33082 -0.002500001] 0.9954199 0 0 0.0955994 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA067,5000408, 0xF3DA0002, 22.33802, 38.09976, -0.002500001, 0.9421682, 0, 0, -0.3351405, False, '2020-01-12 01:08:39'); /* Helmet */
/* @teleloc 0xF3DA0002 [22.33802 38.09976 -0.002500001] 0.9421682 0 0 -0.3351405 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA068,5000423, 0xF3DA000A, 24.6025, 35.66634, -0.002500016, 0.7539419, 0, 0, -0.6569411, False, '2020-01-12 01:08:54'); /* Kabuton */
/* @teleloc 0xF3DA000A [24.6025 35.66634 -0.002500016] 0.7539419 0 0 -0.6569411 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA069,5000422, 0xF3DA000A, 24.41815, 32.26404, -0.002500016, 0.5782172, 0, 0, -0.8158829, False, '2020-01-12 01:09:06'); /* Kabuton */
/* @teleloc 0xF3DA000A [24.41815 32.26404 -0.002500016] 0.5782172 0 0 -0.8158829 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA06A,5000399, 0xF3DA0002, 18.56326, 30.20278, -0.002500001, -0.3273128, 0, 0, -0.9449161, False, '2020-01-12 01:09:24'); /* Helmet */
/* @teleloc 0xF3DA0002 [18.56326 30.20278 -0.002500001] -0.3273128 0 0 -0.9449161 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA06B,5000414, 0xF3DA0002, 15.1414, 34.7005, -0.015, -0.7649465, 0, 0, -0.6440938, False, '2020-01-12 01:09:43'); /* Horned Helm */
/* @teleloc 0xF3DA0002 [15.1414 34.7005 -0.015] -0.7649465 0 0 -0.6440938 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA06C,5000414, 0xF3DA0002, 17.44445, 38.22342, -0.015, -0.9590017, 0, 0, -0.2834004, False, '2020-01-12 01:09:59'); /* Horned Helm */
/* @teleloc 0xF3DA0002 [17.44445 38.22342 -0.015] -0.9590017 0 0 -0.2834004 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA06D,5000419, 0xF3DA0002, 21.33464, 39.60237, -0.002500001, -1, 0, 0, 0.0001619817, False, '2020-01-12 01:10:08'); /* Chiran Helm */
/* @teleloc 0xF3DA0002 [21.33464 39.60237 -0.002500001] -1 0 0 0.0001619817 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA06E,5000422, 0xF3DA000A, 24.19069, 37.84035, -0.002500016, -0.9393171, 0, 0, 0.3430501, False, '2020-01-12 01:10:20'); /* Kabuton */
/* @teleloc 0xF3DA000A [24.19069 37.84035 -0.002500016] -0.9393171 0 0 0.3430501 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA06F,5000404, 0xF3DA000A, 25.75747, 34.0165, -0.002500001, -0.7229995, 0, 0, 0.6908486, False, '2020-01-12 01:10:40'); /* Helmet */
/* @teleloc 0xF3DA000A [25.75747 34.0165 -0.002500001] -0.7229995 0 0 0.6908486 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA070,5000405, 0xF3DA000A, 24.1519, 29.99362, -0.002500001, -0.3270065, 0, 0, 0.945022, False, '2020-01-12 01:10:47'); /* Helmet */
/* @teleloc 0xF3DA000A [24.1519 29.99362 -0.002500001] -0.3270065 0 0 0.945022 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA071,5000397, 0xF3DA0002, 18.77854, 39.87028, -0.002499998, 0.9761387, 0, 0, 0.2171481, False, '2020-01-12 01:12:29'); /* Helmet */
/* @teleloc 0xF3DA0002 [18.77854 39.87028 -0.002499998] 0.9761387 0 0 0.2171481 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA072,5000397, 0xF3DA0002, 23.41031, 39.61502, -0.002499998, 0.9858193, 0, 0, -0.1678103, False, '2020-01-12 01:12:38'); /* Helmet */
/* @teleloc 0xF3DA0002 [23.41031 39.61502 -0.002499998] 0.9858193 0 0 -0.1678103 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA073,5000416, 0xF3DA0002, 23.41031, 39.61502, -0.002499998, 0.903209, 0, 0, -0.4292011, False, '2020-01-12 01:13:05'); /* Chiran Helm */
/* @teleloc 0xF3DA0002 [23.41031 39.61502 -0.002499998] 0.903209 0 0 -0.4292011 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA074,5000416, 0xF3DA000A, 26.00867, 36.2672, -0.002499998, 0.8146864, 0, 0, -0.5799017, False, '2020-01-12 01:13:12'); /* Chiran Helm */
/* @teleloc 0xF3DA000A [26.00867 36.2672 -0.002499998] 0.8146864 0 0 -0.5799017 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA075,5000420, 0xF3DA000A, 26.00867, 36.2672, -0.002499998, 0.8146864, 0, 0, -0.5799017, False, '2020-01-12 01:13:37'); /* Chiran Helm */
/* @teleloc 0xF3DA000A [26.00867 36.2672 -0.002499998] 0.8146864 0 0 -0.5799017 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA076,5000420, 0xF3DA000A, 26.04128, 31.91075, -0.002499998, 0.5245515, 0, 0, -0.8513787, False, '2020-01-12 01:13:56'); /* Chiran Helm */
/* @teleloc 0xF3DA000A [26.04128 31.91075 -0.002499998] 0.5245515 0 0 -0.8513787 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA077,5000420, 0xF3DA0002, 19.8052, 28.94847, -0.002499998, -0.02280999, 0, 0, -0.9997398, False, '2020-01-12 01:14:04'); /* Chiran Helm */
/* @teleloc 0xF3DA0002 [19.8052 28.94847 -0.002499998] -0.02280999 0 0 -0.9997398 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA078,5000412, 0xF3DA0002, 16.45815, 30.49547, -0.015, -0.4103263, 0, 0, -0.9119387, False, '2020-01-12 01:15:03'); /* Horned Helm */
/* @teleloc 0xF3DA0002 [16.45815 30.49547 -0.015] -0.4103263 0 0 -0.9119387 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA079,5000412, 0xF3DA000A, 27.76797, 34.06485, -0.015, -0.6862208, 0, 0, 0.7273934, False, '2020-01-12 01:15:20'); /* Horned Helm */
/* @teleloc 0xF3DA000A [27.76797 34.06485 -0.015] -0.6862208 0 0 0.7273934 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA07A,5000412, 0xF3DA0002, 22.68827, 28.42254, -0.015, 0.1720132, 0, 0, -0.9850947, False, '2020-01-12 01:15:30'); /* Horned Helm */
/* @teleloc 0xF3DA0002 [22.68827 28.42254 -0.015] 0.1720132 0 0 -0.9850947 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA07B,5000416, 0xF3DA0002, 17.51907, 28.56628, -0.002500001, -0.2494643, 0, 0, -0.968384, False, '2020-01-12 01:15:45'); /* Chiran Helm */
/* @teleloc 0xF3DA0002 [17.51907 28.56628 -0.002500001] -0.2494643 0 0 -0.968384 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA07C,5000416, 0xF3DA0002, 14.63294, 32.02734, -0.002500001, -0.5436023, 0, 0, -0.8393429, False, '2020-01-12 01:15:56'); /* Chiran Helm */
/* @teleloc 0xF3DA0002 [14.63294 32.02734 -0.002500001] -0.5436023 0 0 -0.8393429 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA07D,5000416, 0xF3DA0002, 15.25835, 37.12675, -0.002500001, -0.8794582, 0, 0, -0.4759761, False, '2020-01-12 01:16:08'); /* Chiran Helm */
/* @teleloc 0xF3DA0002 [15.25835 37.12675 -0.002500001] -0.8794582 0 0 -0.4759761 */


INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA07E,5000204, 0xF3DA0001, 4.764369, 17.26006, 0.055, 0.8178838, 0, 0, -0.5753834, False, '2020-01-12 01:51:15'); /* Tall Tree */
/* @teleloc 0xF3DA0001 [4.764369 17.26006 0.055] 0.8178838 0 0 -0.5753834 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA07F,5000204, 0xF3DA0001, 13.89381, 12.3528, 0.055, 0.5116049, 0, 0, -0.8592208, False, '2020-01-12 01:51:17'); /* Tall Tree */
/* @teleloc 0xF3DA0001 [13.89381 12.3528 0.055] 0.5116049 0 0 -0.8592208 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA080,5000204, 0xF3DA0001, 16.00717, 3.332858, 0.055, 0.07592288, 0, 0, -0.9971137, False, '2020-01-12 01:51:19'); /* Tall Tree */
/* @teleloc 0xF3DA0001 [16.00717 3.332858 0.055] 0.07592288 0 0 -0.9971137 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA081,5000204, 0xF3DA0004, 0.008514404, 90.84798, 0.055, -0.9293351, 0, 0, 0.3692373, False, '2020-01-12 01:51:34'); /* Tall Tree */
/* @teleloc 0xF3DA0004 [0.008514404 90.84798 0.055] -0.9293351 0 0 0.3692373 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA082,5000204, 0xF3DA0005, 2.97581, 116.9271, 0.055, -0.9978206, 0, 0, -0.06598628, False, '2020-01-12 01:51:37'); /* Tall Tree */
/* @teleloc 0xF3DA0005 [2.97581 116.9271 0.055] -0.9978206 0 0 -0.06598628 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA083,5000204, 0xF3DA000E, 24.79261, 123.7248, 0.055, -0.7463813, 0, 0, 0.6655185, False, '2020-01-12 01:51:39'); /* Tall Tree */
/* @teleloc 0xF3DA000E [24.79261 123.7248 0.055] -0.7463813 0 0 0.6655185 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA084,5000204, 0xF3DA0008, 14.17148, 171.9211, 0.055, -0.9853603, 0, 0, -0.1704852, False, '2020-01-12 01:51:44'); /* Tall Tree */
/* @teleloc 0xF3DA0008 [14.17148 171.9211 0.055] -0.9853603 0 0 -0.1704852 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA085,5000204, 0xF3DA0021, 110.8755, 2.02823, 0.05499998, 0.9966584, 0, 0, 0.08168247, False, '2020-01-12 01:54:23'); /* Tall Tree */
/* @teleloc 0xF3DA0021 [110.8755 2.02823 0.05499998] 0.9966584 0 0 0.08168247 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA086,5000204, 0xF3DA0034, 164.541, 93.62798, 0.05499998, 0.9998896, 0, 0, -0.01485726, False, '2020-01-12 01:54:31'); /* Tall Tree */
/* @teleloc 0xF3DA0034 [164.541 93.62798 0.05499998] 0.9998896 0 0 -0.01485726 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA087,5000204, 0xF3DA002E, 137.7997, 120.001, 0.05499998, 0.9317194, 0, 0, 0.363179, False, '2020-01-12 01:54:35'); /* Tall Tree */
/* @teleloc 0xF3DA002E [137.7997 120.001 0.05499998] 0.9317194 0 0 0.363179 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA088,5000204, 0xF3DA002E, 141.4709, 129.536, 0.05499998, 0.9685668, 0, 0, -0.2487536, False, '2020-01-12 01:54:37'); /* Tall Tree */
/* @teleloc 0xF3DA002E [141.4709 129.536 0.05499998] 0.9685668 0 0 -0.2487536 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA089,5000204, 0xF3DA0030, 129.2596, 184.7393, 0.05499998, 0.785471, 0, 0, 0.6188985, False, '2020-01-12 01:54:42'); /* Tall Tree */
/* @teleloc 0xF3DA0030 [129.2596 184.7393 0.05499998] 0.785471 0 0 0.6188985 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA08A,5000642, 0xF3DA0029, 141.7169, 23.66224, 0.005000055, -0.7777809, 0, 0, 0.6285354, False, '2020-01-15 17:29:10'); /* Camren Knotley */
/* @teleloc 0xF3DA0029 [141.7169 23.66224 0.005000055] -0.7777809 0 0 0.6285354 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA08B,5000635, 0xF3DA0030, 134.7408, 190.6404, 0.003000021, -0.5683523, 0, 0, -0.8227853, False, '2020-01-15 17:30:34'); /* Kimmie Mendenhall */
/* @teleloc 0xF3DA0030 [134.7408 190.6404 0.003000021] -0.5683523 0 0 -0.8227853 */


INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA08C,5000346, 0xF3DA0008, 0.01704407, 171.3304, 0.055, 0.8511559, 0, 0, -0.5249131, False, '2020-01-17 12:20:12'); /* ChickenGen */
/* @teleloc 0xF3DA0008 [0.01704407 171.3304 0.055] 0.8511559 0 0 -0.5249131 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA08D,5000346, 0xF3DA0008, 11.04471, 176.8707, 0.055, 0.8511559, 0, 0, -0.5249131, False, '2020-01-17 12:20:13'); /* ChickenGen */
/* @teleloc 0xF3DA0008 [11.04471 176.8707 0.055] 0.8511559 0 0 -0.5249131 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA08E,5000346, 0xF3DA0016, 48.20475, 140.4112, 0.055, 0.3033633, 0, 0, -0.952875, False, '2020-01-17 12:20:18'); /* ChickenGen */
/* @teleloc 0xF3DA0016 [48.20475 140.4112 0.055] 0.3033633 0 0 -0.952875 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA08F,5000346, 0xF3DA000B, 41.54418, 71.98588, 0.055, -0.1007398, 0, 0, -0.9949128, False, '2020-01-17 12:20:25'); /* ChickenGen */
/* @teleloc 0xF3DA000B [41.54418 71.98588 0.055] -0.1007398 0 0 -0.9949128 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA090,5000346, 0xF3DA0011, 56.38489, 23.79744, 0.055, 0.2918754, 0, 0, -0.9564564, False, '2020-01-17 12:20:29'); /* ChickenGen */
/* @teleloc 0xF3DA0011 [56.38489 23.79744 0.055] 0.2918754 0 0 -0.9564564 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA091,5000346, 0xF3DA0021, 96.02982, 20.72686, 0.055, 0.875426, 0, 0, -0.4833522, False, '2020-01-17 12:20:32'); /* ChickenGen */
/* @teleloc 0xF3DA0021 [96.02982 20.72686 0.055] 0.875426 0 0 -0.4833522 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA092,5000346, 0xF3DA002B, 124.421, 64.11961, 0.055, 0.9839185, 0, 0, -0.1786179, False, '2020-01-17 12:20:37'); /* ChickenGen */
/* @teleloc 0xF3DA002B [124.421 64.11961 0.055] 0.9839185 0 0 -0.1786179 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA093,5000346, 0xF3DA0030, 140.0676, 168.3667, 0.055, 0.9879319, 0, 0, -0.1548889, False, '2020-01-17 12:20:45'); /* ChickenGen */
/* @teleloc 0xF3DA0030 [140.0676 168.3667 0.055] 0.9879319 0 0 -0.1548889 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA094,5000346, 0xF3DA0028, 119.7137, 185.2099, 0.055, 0.8437946, 0, 0, 0.5366662, False, '2020-01-17 12:20:47'); /* ChickenGen */
/* @teleloc 0xF3DA0028 [119.7137 185.2099 0.055] 0.8437946 0 0 0.5366662 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA095,5000347, 0xF3DA0027, 111.3444, 167.5585, 0.055, 0.03747175, 0, 0, -0.9992977, False, '2020-01-17 12:21:31'); /* Moo Cow */
/* @teleloc 0xF3DA0027 [111.3444 167.5585 0.055] 0.03747175 0 0 -0.9992977 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA096,5000347, 0xF3DA001E, 73.74798, 139.1576, 0.055, -0.7290149, 0, 0, -0.6844978, False, '2020-01-17 12:21:35'); /* Moo Cow */
/* @teleloc 0xF3DA001E [73.74798 139.1576 0.055] -0.7290149 0 0 -0.6844978 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA097,5000331, 0xF3DA0023, 110.1223, 55.79247, 0.0005999655, 0.8889386, 0, 0, 0.4580264, False, '2020-01-17 12:23:49'); /* Field Kitties */
/* @teleloc 0xF3DA0023 [110.1223 55.79247 0.0005999655] 0.8889386 0 0 0.4580264 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA098,5000331, 0xF3DA0002, 21.34045, 40.30644, 0.0005999655, 0.6299843, 0, 0, -0.7766079, False, '2020-01-17 12:24:05'); /* Field Kitties */
/* @teleloc 0xF3DA0002 [21.34045 40.30644 0.0005999655] 0.6299843 0 0 -0.7766079 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA099,5000331, 0xF3DA0005, 7.803073, 102.9071, 0.0005999655, -0.9996681, 0, 0, -0.02576458, False, '2020-01-17 12:24:13'); /* Field Kitties */
/* @teleloc 0xF3DA0005 [7.803073 102.9071 0.0005999655] -0.9996681 0 0 -0.02576458 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA09A,5000206, 0xF3DA0009, 28.83284, 5.024734, 0.055, 0.995606, 0, 0, -0.09364113, False, '2020-01-12 15:39:22'); /* Tall Tree */
/* @teleloc 0xF3DA0009 [28.83284 5.024734 0.055] 0.995606 0 0 -0.09364113 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA09B,5000206, 0xF3DA0009, 26.71377, 13.82204, 0.055, 0.90846, 0, 0, 0.4179718, False, '2020-01-12 15:39:24'); /* Tall Tree */
/* @teleloc 0xF3DA0009 [26.71377 13.82204 0.055] 0.90846 0 0 0.4179718 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA09C,5000206, 0xF3DA0001, 13.22309, 16.94144, 0.055, 0.6636218, 0, 0, 0.7480682, False, '2020-01-12 15:39:26'); /* Tall Tree */
/* @teleloc 0xF3DA0001 [13.22309 16.94144 0.055] 0.6636218 0 0 0.7480682 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA09D,5000206, 0xF3DA0004, 7.08095, 81.47078, 0.055, 0.9794833, 0, 0, -0.2015254, False, '2020-01-12 15:39:32'); /* Tall Tree */
/* @teleloc 0xF3DA0004 [7.08095 81.47078 0.055] 0.9794833 0 0 -0.2015254 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA09E,5000206, 0xF3DA0005, 9.7801, 96.7095, 0.055, 0.999571, 0, 0, 0.02928799, False, '2020-01-12 15:39:34'); /* Tall Tree */
/* @teleloc 0xF3DA0005 [9.7801 96.7095 0.055] 0.999571 0 0 0.02928799 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA09F,5000206, 0xF3DA0007, 9.710502, 154.603, 0.055, 0.9567372, 0, 0, -0.2909533, False, '2020-01-12 15:39:40'); /* Tall Tree */
/* @teleloc 0xF3DA0007 [9.710502 154.603 0.055] 0.9567372 0 0 -0.2909533 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA100,5000206, 0xF3DA0008, 2.559381, 176.7593, 0.055, 0.94248, 0, 0, 0.3342625, False, '2020-01-12 15:39:42'); /* Tall Tree */
/* @teleloc 0xF3DA0008 [2.559381 176.7593 0.055] 0.94248 0 0 0.3342625 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA101,5000206, 0xF3DA0030, 138.7259, 191.6672, 0.055, 0.175703, 0, 0, 0.9844432, False, '2020-01-12 15:40:40'); /* Tall Tree */
/* @teleloc 0xF3DA0030 [138.7259 191.6672 0.055] 0.175703 0 0 0.9844432 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA102,5000206, 0xF3DA002F, 134.3893, 167.948, 0.055, -0.1459281, 0, 0, 0.9892952, False, '2020-01-12 15:40:42'); /* Tall Tree */
/* @teleloc 0xF3DA002F [134.3893 167.948 0.055] -0.1459281 0 0 0.9892952 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA103,5000206, 0xF3DA0036, 146.9834, 131.6392, 0.055, -0.02337801, 0, 0, 0.9997267, False, '2020-01-12 15:40:46'); /* Tall Tree */
/* @teleloc 0xF3DA0036 [146.9834 131.6392 0.055] -0.02337801 0 0 0.9997267 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA104,5000206, 0xF3DA0036, 149.1008, 121.8172, 0.055, -0.3300486, 0, 0, 0.9439639, False, '2020-01-12 15:40:48'); /* Tall Tree */
/* @teleloc 0xF3DA0036 [149.1008 121.8172 0.055] -0.3300486 0 0 0.9439639 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA105,5000206, 0xF3DA0034, 144.4178, 92.71631, 0.05499999, 0.283724, 0, 0, 0.958906, False, '2020-01-12 15:40:51'); /* Tall Tree */
/* @teleloc 0xF3DA0034 [144.4178 92.71631 0.05499999] 0.283724 0 0 0.958906 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA106,5000206, 0xF3DA002B, 141.7814, 67.85278, 0.05499999, -0.08576971, 0, 0, 0.996315, False, '2020-01-12 15:40:53'); /* Tall Tree */
/* @teleloc 0xF3DA002B [141.7814 67.85278 0.05499999] -0.08576971 0 0 0.996315 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA107,5000206, 0xF3DA002B, 134.9247, 54.34797, 0.05499999, 0.3722462, 0, 0, 0.928134, False, '2020-01-12 15:40:54'); /* Tall Tree */
/* @teleloc 0xF3DA002B [134.9247 54.34797 0.05499999] 0.3722462 0 0 0.928134 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA108,5000206, 0xF3DA0033, 156.8997, 52.06407, 0.05499999, -0.754635, 0, 0, 0.6561448, False, '2020-01-12 15:40:57'); /* Tall Tree */
/* @teleloc 0xF3DA0033 [156.8997 52.06407 0.05499999] -0.754635 0 0 0.6561448 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA109,5000206, 0xF3DA0019, 94.42308, 6.162179, 0.055, -0.7662792, 0, 0, -0.6425077, False, '2020-01-12 16:32:21'); /* Tall Tree */
/* @teleloc 0xF3DA0019 [94.42308 6.162179 0.055] -0.7662792 0 0 -0.6425077 */


INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA10A,5000209, 0xF3DA0008, 14.03449, 183.9811, 0.05, 0.4685539, 0, 0, -0.8834349, False, '2020-01-13 00:47:13'); /* Small Pine Tree */
/* @teleloc 0xF3DA0008 [14.03449 183.9811 0.05] 0.4685539 0 0 -0.8834349 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA10B,5000205, 0xF3DA0010, 27.55385, 174.8216, 0.055, 0.4685539, 0, 0, -0.8834349, False, '2020-01-13 00:47:14'); /* Tall Tree */
/* @teleloc 0xF3DA0010 [27.55385 174.8216 0.055] 0.4685539 0 0 -0.8834349 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA10C,5000299, 0xF3DA0007, 23.97423, 158.0477, 0.025, -0.3049902, 0, 0, -0.9523555, False, '2020-01-13 00:47:15'); /* Small Pine Tree */
/* @teleloc 0xF3DA0007 [23.97423 158.0477 0.025] -0.3049902 0 0 -0.9523555 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA10D,5000299, 0xF3DA0007, 23.06067, 145.9273, 0.025, 0.4415857, 0, 0, -0.8972191, False, '2020-01-13 00:47:16'); /* Small Pine Tree */
/* @teleloc 0xF3DA0007 [23.06067 145.9273 0.025] 0.4415857 0 0 -0.8972191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA10E,5000300, 0xF3DA000E, 25.9133, 143.7314, 0.1, 0.4415857, 0, 0, -0.8972191, False, '2020-01-13 00:47:17'); /* Small Pine Tree */
/* @teleloc 0xF3DA000E [25.9133 143.7314 0.1] 0.4415857 0 0 -0.8972191 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA10F,5000299, 0xF3DA000E, 34.78229, 127.9546, 0.025, -0.3620853, 0, 0, -0.932145, False, '2020-01-13 00:47:18'); /* Small Pine Tree */
/* @teleloc 0xF3DA000E [34.78229 127.9546 0.025] -0.3620853 0 0 -0.932145 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA110,5000299, 0xF3DA0006, 23.9821, 120.3147, 0.025, -0.7546433, 0, 0, -0.6561353, False, '2020-01-13 00:47:19'); /* Small Pine Tree */
/* @teleloc 0xF3DA0006 [23.9821 120.3147 0.025] -0.7546433 0 0 -0.6561353 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA111,5000299, 0xF3DA0006, 18.89072, 131.0186, 0.025, -0.9957718, 0, 0, 0.09186158, False, '2020-01-13 00:47:21'); /* Small Pine Tree */
/* @teleloc 0xF3DA0006 [18.89072 131.0186 0.025] -0.9957718 0 0 0.09186158 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA112,5000299, 0xF3DA0005, 12.81874, 105.4781, 0.025, 0.5038383, 0, 0, -0.863798, False, '2020-01-13 00:47:24'); /* Small Pine Tree */
/* @teleloc 0xF3DA0005 [12.81874 105.4781 0.025] 0.5038383 0 0 -0.863798 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA113,5000300, 0xF3DA0004, 18.5249, 95.62625, 0.1, -0.1975646, 0, 0, -0.9802899, False, '2020-01-13 00:47:25'); /* Small Pine Tree */
/* @teleloc 0xF3DA0004 [18.5249 95.62625 0.1] -0.1975646 0 0 -0.9802899 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA114,5000299, 0xF3DA0001, 10.8617, 13.1134, 0.025, 0.9993836, 0, 0, 0.03510711, False, '2020-01-13 00:47:40'); /* Small Pine Tree */
/* @teleloc 0xF3DA0001 [10.8617 13.1134 0.025] 0.9993836 0 0 0.03510711 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA115,5000209, 0xF3DA0001, 22.67448, 10.36321, 0.05, 0.1296047, 0, 0, -0.9915658, False, '2020-01-13 00:47:42'); /* Small Pine Tree */
/* @teleloc 0xF3DA0001 [22.67448 10.36321 0.05] 0.1296047 0 0 -0.9915658 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA116,5000209, 0xF3DA0019, 90.76901, 7.079838, 0.05, 0.9962553, 0, 0, 0.08646052, False, '2020-01-13 00:47:56'); /* Small Pine Tree */
/* @teleloc 0xF3DA0019 [90.76901 7.079838 0.05] 0.9962553 0 0 0.08646052 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA117,5000209, 0xF3DA0021, 108.542, 9.690031, 0.05, -0.06995755, 0, 0, -0.99755, False, '2020-01-13 00:47:59'); /* Small Pine Tree */
/* @teleloc 0xF3DA0021 [108.542 9.690031 0.05] -0.06995755 0 0 -0.99755 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA118,5000299, 0xF3DA0022, 112.8059, 24.12976, 0.025, 0.9999663, 0, 0, 0.008209584, False, '2020-01-13 00:48:04'); /* Small Pine Tree */
/* @teleloc 0xF3DA0022 [112.8059 24.12976 0.025] 0.9999663 0 0 0.008209584 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA119,5000300, 0xF3DA0022, 101.3596, 41.03652, 0.1, 0.9104286, 0, 0, 0.4136663, False, '2020-01-13 00:48:06'); /* Small Pine Tree */
/* @teleloc 0xF3DA0022 [101.3596 41.03652 0.1] 0.9104286 0 0 0.4136663 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA11A,5000209, 0xF3DA0024, 98.73987, 85.90665, 0.05, 0.9581477, 0, 0, -0.2862743, False, '2020-01-13 00:48:09'); /* Small Pine Tree */
/* @teleloc 0xF3DA0024 [98.73987 85.90665 0.05] 0.9581477 0 0 -0.2862743 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA11B,5000205, 0xF3DA0025, 105.372, 96.01494, 0.055, 0.9581477, 0, 0, -0.2862743, False, '2020-01-13 00:48:10'); /* Tall Tree */
/* @teleloc 0xF3DA0025 [105.372 96.01494 0.055] 0.9581477 0 0 -0.2862743 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA11C,5000207, 0xF3DA0025, 105.6752, 104.8553, 0.055, 0.9408352, 0, 0, 0.3388645, False, '2020-01-13 00:48:11'); /* Tall Tree */
/* @teleloc 0xF3DA0025 [105.6752 104.8553 0.055] 0.9408352 0 0 0.3388645 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA11D,5000299, 0xF3DA0026, 96.01567, 124.9491, 0.025, 0.9390597, 0, 0, -0.3437542, False, '2020-01-13 00:48:12'); /* Small Pine Tree */
/* @teleloc 0xF3DA0026 [96.01567 124.9491 0.025] 0.9390597 0 0 -0.3437542 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA11E,5000300, 0xF3DA0025, 113.4525, 119.9649, 0.1, 0.4553659, 0, 0, -0.8903044, False, '2020-01-13 00:48:13'); /* Small Pine Tree */
/* @teleloc 0xF3DA0025 [113.4525 119.9649 0.1] 0.4553659 0 0 -0.8903044 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA11F,5000209, 0xF3DA002E, 131.9745, 120.0511, 0.05, 0.903994, 0, 0, -0.4275452, False, '2020-01-13 00:48:15'); /* Small Pine Tree */
/* @teleloc 0xF3DA002E [131.9745 120.0511 0.05] 0.903994 0 0 -0.4275452 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA120,5000300, 0xF3DA0036, 144.4192, 128.2747, 0.1, 0.7001889, 0, 0, -0.7139576, False, '2020-01-13 00:48:16'); /* Small Pine Tree */
/* @teleloc 0xF3DA0036 [144.4192 128.2747 0.1] 0.7001889 0 0 -0.7139576 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA121,5000300, 0xF3DA0035, 149.68, 115.5722, 0.1, 0.3176576, 0, 0, -0.9482055, False, '2020-01-13 00:48:17'); /* Small Pine Tree */
/* @teleloc 0xF3DA0035 [149.68 115.5722 0.1] 0.3176576 0 0 -0.9482055 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA122,5000299, 0xF3DA0035, 158.3196, 106.6784, 0.025, 0.6261588, 0, 0, -0.7796956, False, '2020-01-13 00:48:18'); /* Small Pine Tree */
/* @teleloc 0xF3DA0035 [158.3196 106.6784 0.025] 0.6261588 0 0 -0.7796956 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA123,5000299, 0xF3DA003C, 168.581, 95.72624, 0.025, 0.01028288, 0, 0, -0.9999471, False, '2020-01-13 00:48:19'); /* Small Pine Tree */
/* @teleloc 0xF3DA003C [168.581 95.72624 0.025] 0.01028288 0 0 -0.9999471 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA124,5000299, 0xF3DA0034, 167.9702, 89.96204, 0.025, -0.229944, 0, 0, -0.9732039, False, '2020-01-13 00:48:20'); /* Small Pine Tree */
/* @teleloc 0xF3DA0034 [167.9702 89.96204 0.025] -0.229944 0 0 -0.9732039 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA125,5000205, 0xF3DA0036, 159.7318, 126.4135, 0.055, -0.9933899, 0, 0, 0.1147891, False, '2020-01-13 00:48:24'); /* Tall Tree */
/* @teleloc 0xF3DA0036 [159.7318 126.4135 0.055] -0.9933899 0 0 0.1147891 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA126,5000209, 0xF3DA0037, 149.8743, 155.2106, 0.05, -0.9585875, 0, 0, -0.2847982, False, '2020-01-13 00:48:26'); /* Small Pine Tree */
/* @teleloc 0xF3DA0037 [149.8743 155.2106 0.05] -0.9585875 0 0 -0.2847982 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA127,5000299, 0xF3DA0030, 133.1456, 191.6509, 0.025, -0.3611542, 0, 0, -0.9325061, False, '2020-01-13 00:48:31'); /* Small Pine Tree */
/* @teleloc 0xF3DA0030 [133.1456 191.6509 0.025] -0.3611542 0 0 -0.9325061 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA128,5000299, 0xF3DA0030, 131.5915, 185.5135, 0.025, 0.3299612, 0, 0, -0.9439945, False, '2020-01-13 00:48:32'); /* Small Pine Tree */
/* @teleloc 0xF3DA0030 [131.5915 185.5135 0.025] 0.3299612 0 0 -0.9439945 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F3DA129, 5000398, 0xF3DA0002, 22.00091, 29.91377, -0.002500001, 0.165773, 0, 0, -0.986164, False, '2020-01-12 01:09:14'); /* Helmet */
/* @teleloc 0xF3DA0002 [22.00091 29.91377 -0.002500001] 0.165773 0 0 -0.986164 */
