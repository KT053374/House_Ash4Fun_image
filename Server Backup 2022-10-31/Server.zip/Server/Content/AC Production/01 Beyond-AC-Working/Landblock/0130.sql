
DELETE FROM landblock_instance WHERE landblock=0x0130 AND weenie_Class_Id=5637;

INSERT INTO `landblock_instance` (`guid`,`weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
	VALUES (0x70130500, 5637, 19923238, 29.5637, -62.1342, 5.937, -0.016703, 0, 0, -0.999861, False, '2019-07-27 14:14:00'); /* Linkable Monster Generator ( 5 Min.) */
/* @teleloc 01300126 29.5637 -62.1342 5.937 -0.016703 0 0 -0.999861 */;