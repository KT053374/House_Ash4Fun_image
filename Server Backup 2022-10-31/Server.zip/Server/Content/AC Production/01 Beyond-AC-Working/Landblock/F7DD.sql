DELETE FROM `landblock_instance` WHERE `landblock` = 0xF7DD;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F7DD000, 5000768, 0xF7DD0004, 0.114471, 80.4044, -0.845, -0.638345, 0, 0, 0.76975, False, '2020-05-20 20:48:12'); /* Stealth Remoran gen */
/* @teleloc 0xF7DD0004 [0.114471 80.404404 -0.845000] -0.638345 0.000000 0.000000 0.769750 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F7DD001, 5000768, 0xF7DD0004, 7.942672, 77.27716, -0.84499985, -0.32299417, 0, 0, 0.94640094, False, '2020-05-20 20:48:13'); /* Stealth Remoran gen */
/* @teleloc 0xF7DD0004 [7.942672 77.277161 -0.845000] -0.322994 0.000000 0.000000 0.946401 */
