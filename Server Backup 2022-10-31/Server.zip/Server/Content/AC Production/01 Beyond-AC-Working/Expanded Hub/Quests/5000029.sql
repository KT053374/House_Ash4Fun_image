
DELETE FROM `quest` WHERE (`id` = '5000029');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000029', 'WardenPhantom', '0', '1', 'WardenPhantom', '2019-09-05 19:03:38');