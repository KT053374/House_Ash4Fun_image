
DELETE FROM `quest` WHERE (`id` = '5000022');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000022', 'WardenElariBow', '0', '1', 'WardenElariBow', '2019-09-05 19:03:38');