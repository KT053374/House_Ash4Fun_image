
DELETE FROM `quest` WHERE (`id` = '5000026');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000026', 'WardenHeart', '0', '1', 'WardenHeart', '2019-09-05 19:03:38');